import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Topic } from './Topic';


@Injectable({
  providedIn: 'root'
})
export class TopicService {

  constructor(public http: HttpClient) {
  }

  
  public saveTopic( topic ){
    return this.http.post('http://localhost:9090/Topic/topic', topic, {responseType: 'text' as 'json'});
  }

  public displayTopics (){
        return this.http.get('http://localhost:9090/Topic/alltopics');

}

public deleteAllTopics (){
  return this.http.delete('http://localhost:9090/Topic/user/deleteallTopics');

}

public findTopicById(id){
  return this.http.get('http://localhost:9090/Topic/findTopic/'+id);
}

public DeleteTopicById(id){
  console.log('topicservice.service.ts delete method: Id = ' + id);
  return this.http.delete('http://localhost:9090/Topic/cancel/'+id);

  }

  public updateTopicById(topic,id){
    console.log('topicservice.service.ts update method: Id = ' + id);

    return this.http.put('http://localhost:9090/Topic/user/update/'+id,topic);

  }
}