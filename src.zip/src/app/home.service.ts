import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Login } from './Login';

@Injectable({
  providedIn: 'root'
})
export class HomeService {


  constructor(public http: HttpClient) {
  }
  
  
  public doLogin( login ){
    return this.http.post('http://localhost:9090/Login/login', login, {responseType: 'text' as 'json'});
  }

  public displayUsers (login){
        return this.http.get('http://localhost:9090/Login/user/all')

}

public deleteUsers (){
  return this.http.delete('http://localhost:9090/Login/user/deleteall')

}

public deleteUserById ( index ){
  
  return this.http.delete('http://localhost:9090/Login/user/delete/{id}',index)

}



}