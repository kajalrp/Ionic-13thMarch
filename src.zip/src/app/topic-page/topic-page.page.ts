import { Component, OnInit, ViewChild} from '@angular/core';
import { RouterModule } from '@angular/router';
import { TopicService } from '../topic.service';
import {Topic} from '../Topic';
import {Login} from '../Login';
import {ActivatedRoute} from '@angular/router';
import { trigger, state, style, transition, animate } from '@angular/animations';

import { ColumnMode, SelectionType } from '@swimlane/ngx-datatable';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HomePage } from '../home/home.page';

@Component({
  selector: 'app-topic-page',
  templateUrl: './topic-page.page.html',
  styleUrls: ['./topic-page.page.scss'],
})
export class TopicPagePage {


  // tslint:disable-next-line: max-line-length
  constructor(public navCtrl: NavController,public alertCtrl: AlertController,private router: Router, public activateRoute: ActivatedRoute,public service: TopicService, public alertController: AlertController) {
    setTimeout(() => {
      this.loadingIndicator = false;
    }, 1500);
  }
  myDate: string = new Date().toISOString();
  getName: string = this.activateRoute.snapshot.paramMap.get('namedata');
  confirmedExit: boolean = false;
selectedTopic = '';
checked = false;
  public pepperoni = true;
  public sausage = true;
  public mushrooms = true;
  public toogle = true;
  public selectiontoggle = false;

  selected = [];
  temp = [];
  editing = {};
  reorderable = true;
  selectedTheme: 'string';
  row = [];
  SelectionType = SelectionType;
  loadingIndicator = true;
  
  login: Login;
  topic: Topic = new Topic("","","",this.getName,this.myDate,this.getName,this.myDate);
  message: any;
  public allTopics:any=[];
  
  tab1 = true;
  tab2 = false;
  tab3 = false;
  tab4 = false;
  tab5 = false;

  
  @ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;
tablestyle = 'bootstrap';

selectedArray :any = [];
selectedColumnsToggle : string = '';

 

  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `http://localhost:9090/Topic/alltopics`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      
      message: 'Topic details are saved',
      buttons: ['OK'],
    });
  
    await alert.present();
    let result = await alert.onDidDismiss();
    console.log(result);
  }

  public SaveTopic(){
    let resp = this.service.saveTopic(this.topic);
    resp.subscribe((data)=>this.message =data);
    this.presentSavedAlert();
    console.log(resp);

  }
public DisplayAllTopics(){
  let resp = this.service.displayTopics();
  resp.subscribe((data)=>this.allTopics =data);
  console.log(this.allTopics);

  }


// public FindTopicById(id: any){
//   let resp = this.service.findTopicById(id);
//   resp.subscribe((data)=>this.topic=data);
//   }

public DeleteAllTopics(){
  let resp = this.service.deleteAllTopics();
  resp.subscribe((data)=> this.allTopics =data);
  }


// public UpdateTopic(){
//   let resp = this.service.updateTopicById();
//   resp.subscribe((data)=> th
filterItems(login) {
  return this.allTopics.filter(item => {
    return item.title.toLowerCase().indexOf(login.toLowerCase()) > -1;
  });
}
deleteTopic(id: number) {
  
  let res = this.service.DeleteTopicById(id)
  res.subscribe((data)=> this.allTopics =data);
  this.presentDeleteAlert();
}

deleteTopic1(rowIndex: number) {

  let res = this.service.DeleteTopicById(this.allTopics[rowIndex].id);
  res.subscribe((data)=> this.allTopics =data);
  this.presentDeleteAlert();
}


    goToTopicModifypage(id){
      console.log("In topic.page.ts "+id);
      console.log("In topic.page.ts "+this.topic.topic_name);
      console.log("In topic.page.ts "+this.topic.topic_description);
      console.log("In topic.page.ts "+this.topic.created_by);

     // this.router.navigate(['topic-modify',{namedata3: id, this.topic.topic_description,this.topic.topic_name}]);
      // this.router.navigate(['topic-modify',{namedata2: this.topic.topic_description}]);
      // this.router.navigate(['topic-modify',{namedata1: this.topic.topic_name}]);
      // tslint:disable-next-line: max-line-length
      this.router.navigate(['topic-modify'],{queryParams: {id1:id,namedata1: this.topic.topic_description,namedata2:this.topic.topic_name}});

    }

  
onSelect({ selected }) {
  console.log('Select Event', selected, this.selected);
  console.log('length'+ this.selected.length)

  this.selected.splice(0, this.selected.length);
  console.log('select aafter: ', this.selected);
  this.selected.push(...selected);
}

onActivate(event) {
  console.log('Activate Event', event);
}


displayCheck(topic) {
  return this.topic.topic_name !== 'Ethel Price';
}

getRowClass = (topic) => {
  return {
    'row-color': true
  };
}

toggleExpandRow(rowIndex) {
  console.log('Toggled Expand Row!', rowIndex);
  this.table.rowDetail.toggleExpandRow(rowIndex);
}

onDetailToggle(event) {
  console.log('Detail Toggled', event);
}

switchStyle(){
  // tslint:disable-next-line: triple-equals
  if (this.tablestyle == 'dark') {
    this.tablestyle = 'bootstrap';
  } else {
    this.tablestyle = 'dark';
  }
}

updateValue(event, cell, rowIndex) {
  console.log('inline editing rowIndex', rowIndex);
  this.editing[rowIndex + '-' + cell] = false;
  console.log('cell no'+cell+'object '+this.allTopics[rowIndex]+'id'+this.allTopics[rowIndex].id);
  console.log(this.allTopics[rowIndex][cell]);
  this.allTopics[rowIndex][cell] = event.target.value;
  console.log('after change value'+this.allTopics[rowIndex][cell]);
  // tslint:disable-next-line: no-unused-expression
  this.myDate = new Date().toISOString();
  this.topic.modified_date = this.myDate;

  let resp =  this.service.updateTopicById(this.allTopics[rowIndex],this.allTopics[rowIndex].id);
   
  resp.subscribe((data)=> this.allTopics =data);

  this.allTopics = [...this.allTopics];
  
  console.log('UPDATED!', this.allTopics[rowIndex][cell]);
}

async presentalert() {
  const alert = await this.alertCtrl.create({
    header: '  DO YOU WANT TO EDIT??',
    message: 'PLEASE ENTER NEW DETAILS',
    cssClass: 'alertCancel',
    mode: 'ios',
    buttons: [
      {
        text: 'NO',
        role: 'cancel',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/topic-page').catch(() => {});

          console.log('Confirm Cancel');
        }
      }, {
        text: 'YES',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/topic-modify').catch(() => {});

          console.log('Confirm Okay');
        }
      }
    ]
  })
  await alert.present();
}

async presentDeleteAlert() {
  const alert = await this.alertCtrl.create({
    header: '  TOPIC DETAILS ARE SUCCESSFULLY DELETED!',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'cancel',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}

async presentDeleteAllAlert() {
  const alert = await this.alertCtrl.create({
    header: '  All TOPIC DETAILS ARE SUCCESSFULLY DELETED!',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'cancel',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}

async presentSavedAlert() {
  const alert = await this.alertCtrl.create({
    header: '  NEW TOPIC DETAILS ARE SUCCESSFULLY ADDED!',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'cancel',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}

async presntCheckboxAlert(row) {
  const alert = await this.alertCtrl.create({
    header: '  YOU HAVE SELECTED TOPIC " '+row.topic_name+ ' "',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'cancel',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}

async presntShowNothingAlert() {
  const alert = await this.alertCtrl.create({
    header: 'YOUR TOPIC DETAILS ARE NOW HIDDEN!',
    message: 'Press FIND ALL TOPICS to view all details!',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'cancel',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}


updateFilter(event) {
  const val = event.target.value.toLowerCase();

  // filter our data
  const temp = this.allTopics.filter(function(d) {
    return d.topic_name.toLowerCase().indexOf(val) !== -1 || !val
  });
  
  // update the rows
  this.allTopics = temp;
 

  // Whenever the filter changes, always go back to the first page
  this.table.offset = 0;
}


doRefresh(event) {
  console.log('Begin async operation');

  setTimeout(() => {
    console.log('Async operation has ended');
    event.target.complete();
  }, 2000);
}


}


