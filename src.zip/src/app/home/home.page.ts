import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { HomeService } from '../home.service';
import {Login} from '../Login';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NavController, NavParams, LoadingController, ToastController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
 login : Login =  new Login("","","");
  message: any;
  public allLogins:any=[];
  public pepperoni = true;
  public sausage = true;
  public mushrooms = true;
  public toogle = true;
  selected = [];
  reorderable = true;
  selectedTheme: 'string';
  
  toast: any;


  // tslint:disable-next-line: max-line-length
  constructor( public toastController: ToastController,public navCtrl: NavController,public alertCtrl: AlertController,private router: Router, public service: HomeService, public alertController: AlertController) {}

  async presentAlert() {
    const alert = await this.alertController.create({
      
      message: 'Topic details are saved',
      buttons: ['OK'],
    });
  
    await alert.present();
    let result = await alert.onDidDismiss();
    console.log(result);
  }

  public loginNow(){
    let resp = this.service.doLogin(this.login);
    resp.subscribe((data)=>this.message =data);
    console.log(resp);

  }


goToTopicpage(){
  console.log("In home.page.ts "+this.login.user_name);
  this.router.navigate(['topic-page',{namedata: this.login.user_name}]);  
}


public DisplayUsers(){
  let resp = this.service.displayUsers(this.login);
  resp.subscribe((data)=>this.allLogins =data);
  }

public DeleteAllUsers(){
  let resp = this.service.deleteUsers();
  resp.subscribe((data)=> this.allLogins =data);
  }

public DeleteUserById(){
  let resp = this.service.deleteUsers();
  resp.subscribe((data)=> this.allLogins =data);
  }

filterItems(login) {
  return this.allLogins.filter(item => {
    return item.title.toLowerCase().indexOf(login.toLowerCase()) > -1;
  });
}
async presentalert() {
  const alert = await this.alertCtrl.create({
    message: 'HI!  ' + this.login.user_name + '!!  YOU ARE SUCCESSFULLY LOGGED IN!:',
    header: 'DO YOU WANT TO ENTER TOPIC ?',
    cssClass: 'alertCancel',
    mode: 'ios',
    buttons: [
      {
        text: 'NO',
        role: 'cancel',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/home').catch(() => {});

          console.log('Confirm Cancel');
        }
      }, {
        text: 'YES',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/topic-oage').catch(() => {});

          console.log('Confirm Okay');
        }
      }
    ]
  })
  await alert.present();
}

showToast() {
  this.toast = this.toastController.create({
    message: 'You are sucessfully logged In!! ',
    cssClass:"my-custom-class",
    duration: 2000,   
       

  }).then((toastData)=>{
    console.log(toastData);
    toastData.present();
  });
}
HideToast(){
  this.toast = this.toastController.dismiss();
}


  }
   