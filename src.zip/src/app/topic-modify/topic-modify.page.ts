import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {Topic} from '../Topic';
import { TopicService } from '../topic.service';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from '@ionic/angular';


@Component({
  selector: 'app-topic-modify',
  templateUrl: './topic-modify.page.html',
  styleUrls: ['./topic-modify.page.scss'],
})
export class TopicModifyPage implements OnInit {

  myDate: string = new Date().toISOString();

  getName: string = this.activateRoute.snapshot.paramMap.get('namedata3');
  //getid: String = this.activateRoute.snapshot.paramMap.get('namedata3');
  //this.route.queryParams.subscribe(params =>{let getid= params['id']});

  getName2: string;
  getName1: string;

  public allTopics:any=[];
  getid:String;

  //topic: Topic = new Topic(this.getid,this.getName1,this.getName2,this.getName,this.myDate,this.getName,this.myDate);
 topic: Topic;


  // tslint:disable-next-line: max-line-length
  constructor(public alertCtrl: AlertController,public navCtrl: NavController,public service: TopicService,private router: Router, public activateRoute: ActivatedRoute) { }

ngOnInit() {
  

  this.topic= new Topic(this.getid,this.getName1,this.getName2,this.getName,this.myDate,this.getName,this.myDate);
  this.activateRoute.queryParams.subscribe(params =>{this.getid= params['id1'];
                                                     this.getName1= params['namedata1'];
                                                     this.getName2= params['namedata2'];});
  this.service.findTopicById(this.getid).subscribe(data=> this.topic=<Topic>data);

  console.log('Init called'+this.getid);
  console.log('findby id obj'+this.topic);

  }

 public updateTopic(){
   console.log(this.getid);
   console.log(this.getName1);
   console.log(this.getName2);
   this.myDate = new Date().toISOString();
   this.topic.modified_date = this.myDate;

   let resp = this.service.updateTopicById(this.topic,this.getid);
   resp.subscribe((data)=> this.allTopics =data);
this.presentUpdatealert();
   

   }

 
async presentalert() {
  const alert = await this.alertCtrl.create({
    header: '  YOU HAVE SUCCESSFULLY UPDATED THE DETAILS',
    message: 'DO YOU NEED TO ADD MORE DETAILS',
    cssClass: 'alertCancel',
    mode: 'ios',
    buttons: [
      {
        text: 'NO',
        role: 'cancel',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/topic-page').catch(() => {});
          console.log('Confirm Cancel');
        }
      }, {
        text: 'YES',
        cssClass: 'alertButton',
        handler: () => {
          this.navCtrl.navigateForward('/topic-modify').catch(() => {});
          console.log('Confirm Okay');
        }
      }
    ]
  })
  await alert.present();
}

async presentUpdatealert() {
  const alert = await this.alertCtrl.create({
    header: '  TOPIC DETAILS ARE SUCCESSFULLY UPDATED!',
    cssClass: 'alertButton',
    mode: 'ios',
    buttons: [
      {
        text: 'OKAY',
        role: 'ok',
        handler: () => {

          console.log('Confirm OKAY');
        }
      }
    ]
  })
  await alert.present();
}




}
