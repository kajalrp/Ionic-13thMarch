import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TopicModifyPageRoutingModule } from './topic-modify-routing.module';

import { TopicModifyPage } from './topic-modify.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TopicModifyPageRoutingModule
  ],
  declarations: [TopicModifyPage]
})
export class TopicModifyPageModule {}
