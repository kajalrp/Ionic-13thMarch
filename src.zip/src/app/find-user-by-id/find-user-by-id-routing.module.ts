import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FindUserByIDPage } from './find-user-by-id.page';

const routes: Routes = [
  {
    path: '',
    component: FindUserByIDPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FindUserByIDPageRoutingModule {}
