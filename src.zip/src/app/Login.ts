export class Login{
    constructor(
        public id: String,
        public user_name: string,
        public password: string,
      
    ){}
}